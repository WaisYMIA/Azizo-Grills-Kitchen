// Demo data for testing on a phone: a few LIVE home kitchens with the full menu, so the Kitchens page has areas,
// kitchens and dishes to order from. Runs only when AZIZO_DEMO=1, only once (when there are no kitchens yet).
// Demo cooks sign in at the partner portal with the email below and the password demo1234.
if (process.env.AZIZO_DEMO !== '1') return;
const db = require('./db');
const bcrypt = require('bcryptjs');
try {
  if (db.prepare('SELECT COUNT(*) AS n FROM kk_kitchens').get().n > 0) return;
  const demo = [
    ['Mama Wanjiru Kitchen', 'Wanjiru Kamau', 'syokimau', 'Pilau, matoke and nyama stew cooked the home way.'],
    ['Chef Achieng Home Kitchen', 'Achieng Odhiambo', 'umoja-1', 'Fish, ugali and traditional Luo dishes.'],
    ['Bi Halima Swahili Kitchen', 'Halima Mohamed', 'buruburu-phase-1', 'Coastal biryani, coconut beans and chapati.'],
    ['Mzee Kariuki Githeri House', 'Peter Kariuki', 'utawala', 'Githeri, mukimo and slow-cooked beef.']
  ];
  const hash = bcrypt.hashSync('demo1234', 8);
  const dishes = db.prepare('SELECT id FROM kk_dishes WHERE active = 1').all();
  const getArea = db.prepare('SELECT id, region, lat, lng FROM areas WHERE id = ?');
  const ins = db.prepare(`INSERT INTO kk_kitchens (slug, name, cook_name, phone, email, password_hash, bio, specialities, address, area_id, region, lat, lng, radius_km, capacity, status, approved_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'live', datetime('now'))`);
  const link = db.prepare('INSERT OR IGNORE INTO kk_kitchen_dishes (kitchen_id, dish_id, available) VALUES (?, ?, 1)');
  db.transaction(() => {
    demo.forEach((d, i) => {
      const a = getArea.get(d[2]); if (!a) return;
      const slug = d[0].toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const r = ins.run(slug, d[0], d[1], '07000000' + (10 + i), 'demo-kitchen-' + (i + 1) + '@azizo.test', hash, d[3], 'Demo kitchen', a.id, a.id, a.region, a.lat, a.lng, 8, 25);
      for (const x of dishes) link.run(r.lastInsertRowid, x.id);
    });
  })();
  console.log('[demo] added demo kitchens (partner login: demo-kitchen-1@azizo.test / demo1234)');
} catch (e) { console.error('[demo] could not add demo data:', e.message); }
