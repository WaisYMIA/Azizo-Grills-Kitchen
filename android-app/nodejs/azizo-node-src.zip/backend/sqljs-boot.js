// Starts the backend on the pure-JavaScript SQLite (sql.js). Used inside the Android app and for testing it.
//   node sqljs-boot.js        (same environment variables as server.js)
const initSqlJs = require('sql.js');
initSqlJs().then((SQL) => { global.__AZIZO_SQLJS = SQL; require('./server'); }).catch((e) => { console.error('sql.js failed to start:', e); process.exit(1); });
