// better-sqlite3-compatible database on top of sql.js (SQLite compiled to WebAssembly, pure JavaScript).
// Used where no native SQLite module can be installed, for example the Node 18 that runs INSIDE the Android app.
// The database lives in memory and is written to its file shortly after every change (and on exit).
const fs = require('fs'), path = require('path');
const num = (v) => (typeof v === 'bigint' ? Number(v) : v);
const fix = (a) => a.map((x) => (typeof x === 'boolean' ? (x ? 1 : 0) : x === undefined ? null : typeof x === 'bigint' ? Number(x) : Buffer.isBuffer(x) ? new Uint8Array(x) : x));
module.exports = function makeDatabase(SQL) {
  const all = new Set();
  const flushAll = () => { for (const d of all) { try { d._save(true); } catch (e) { /* best effort on exit */ } } };
  process.on('exit', flushAll);
  for (const s of ['SIGTERM', 'SIGINT']) process.on(s, () => { flushAll(); process.exit(0); });
  return class Database {
    constructor(file) {
      this._file = file && file !== ':memory:' ? path.resolve(file) : null; this._depth = 0; this.open = true; this._dirty = false; this._timer = null;
      let buf = null;
      if (this._file && fs.existsSync(this._file)) buf = fs.readFileSync(this._file);
      this._d = buf && buf.length ? new SQL.Database(new Uint8Array(buf)) : new SQL.Database();
      this._d.exec('PRAGMA foreign_keys = ON');
      all.add(this);
      if (this._file && !buf) this._touch();
    }
    // test mode only (SQLJS_RELOAD=1): pick up changes that a test script made to the database file directly
    _sync() {
      if (!process.env.SQLJS_RELOAD || !this._file || this._depth > 0 || this._dirty) return;
      try { const m = fs.statSync(this._file).mtimeMs; if (m > (this._mtime || 0)) { this._mtime = m; if (this._seen) { this._d.close(); this._d = new SQL.Database(new Uint8Array(fs.readFileSync(this._file))); this._d.exec('PRAGMA foreign_keys = ON'); } this._seen = true; } } catch (e) { /* file not there yet */ }
    }
    _touch() {
      this._dirty = true;
      if (!this._file) return;
      if (process.env.SQLJS_FLUSH_MS === '0') { if (this._depth === 0) this._save(false); return; }   // test mode: write through immediately
      if (this._timer) return;
      this._timer = setTimeout(() => { this._timer = null; this._save(false); }, Number(process.env.SQLJS_FLUSH_MS || 300));
      if (this._timer.unref) this._timer.unref();
    }
    _save(force) {
      if (!this._file || !this._dirty || !this.open) return;
      if (this._depth > 0 && !force) { this._touch(); return; }   // never export in the middle of a transaction
      const data = Buffer.from(this._d.export());                  // export() resets pragmas
      this._d.exec('PRAGMA foreign_keys = ON');
      const tmp = this._file + '.tmp';
      fs.mkdirSync(path.dirname(this._file), { recursive: true });
      fs.writeFileSync(tmp, data); fs.renameSync(tmp, this._file);
      try { this._mtime = fs.statSync(this._file).mtimeMs; this._seen = true; } catch (e) { /* ignore */ }
      this._dirty = false;
    }
    exec(sql) { this._sync(); this._d.exec(sql); if (!/^\s*(select|pragma)\b/i.test(sql)) this._touch(); return this; }
    pragma(s) {
      if (/journal_mode|synchronous|busy_timeout|wal_|locking_mode/i.test(s)) return [];
      const r = this._d.exec('PRAGMA ' + s); if (!r[0]) return [];
      return r[0].values.map((v) => Object.fromEntries(r[0].columns.map((c, i) => [c, v[i]])));
    }
    prepare(sql) {
      const self = this;
      const params = (a) => {
        if (a.length === 1 && a[0] && typeof a[0] === 'object' && !Array.isArray(a[0]) && !Buffer.isBuffer(a[0]) && !(a[0] instanceof Uint8Array)) {
          const o = {};
          for (const k of Object.keys(a[0])) {
            const m = sql.match(new RegExp('[@:$]' + k.replace(/[^\w]/g, '') + '\\b'));
            if (m) o[m[0]] = fix([a[0][k]])[0];
          }
          return o;
        }
        return fix(Array.isArray(a[0]) ? a[0] : a);
      };
      const use = (a, fn) => { self._sync(); const st = self._d.prepare(sql); try { const p = params(a); if (Array.isArray(p) ? p.length : Object.keys(p).length) st.bind(p); return fn(st); } finally { st.free(); } };
      return {
        get: (...a) => use(a, (st) => (st.step() ? st.getAsObject() : undefined)),
        all: (...a) => use(a, (st) => { const out = []; while (st.step()) out.push(st.getAsObject()); return out; }),
        iterate: (...a) => use(a, (st) => { const out = []; while (st.step()) out.push(st.getAsObject()); return out[Symbol.iterator](); }),
        run: (...a) => use(a, (st) => {
          st.step();
          const changes = self._d.getRowsModified();
          let id = 0;
          if (/^\s*(insert|replace|with)\b/i.test(sql)) { const r = self._d.exec('SELECT last_insert_rowid()'); id = num(r[0].values[0][0]); }
          self._touch();
          return { changes, lastInsertRowid: id };
        }),
      };
    }
    transaction(fn) {
      const self = this;
      const wrap = function (...a) {
        const sp = 'sp' + self._depth; const top = self._depth === 0;
        self._d.exec(top ? 'BEGIN' : 'SAVEPOINT ' + sp); self._depth++;
        try { const r = fn.apply(this, a); self._depth--; self._d.exec(top ? 'COMMIT' : 'RELEASE ' + sp); self._touch(); return r; }
        catch (e) { self._depth--; try { self._d.exec(top ? 'ROLLBACK' : 'ROLLBACK TO ' + sp + '; RELEASE ' + sp); } catch (_) { /* already rolled back */ } throw e; }
      };
      wrap.immediate = wrap.deferred = wrap.exclusive = wrap;
      return wrap;
    }
    async backup(dest) {
      const data = Buffer.from(this._d.export()); this._d.exec('PRAGMA foreign_keys = ON');
      fs.mkdirSync(path.dirname(path.resolve(dest)), { recursive: true }); fs.writeFileSync(dest, data);
    }
    close() { this._save(true); this._d.close(); this.open = false; all.delete(this); }
  };
};
