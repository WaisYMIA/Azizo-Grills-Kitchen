/* Azizo app shell (v6.8.1): turns the website into a mobile-app layout INSIDE the Android app.
   Active only in the app (Capacitor, or the on-phone server at 127.0.0.1) or with ?app=1 (for testing in a browser).
   It loads appshell.css, hides the website header/footer, and adds an app bar, a bottom tab bar and an Options drawer. */
(function () {
  var de = document.documentElement;
  var on = false;
  try { on = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) {}
  try {
    if (/[?&]app=1\b/.test(location.search)) sessionStorage.setItem('azizoApp', '1');
    if (location.hostname === '127.0.0.1' || sessionStorage.getItem('azizoApp') === '1') on = true;
  } catch (e) { if (location.hostname === '127.0.0.1') on = true; }
  if (!on) return;
  de.classList.add('native-app', 'azizo-shell');
  var l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'appshell.css?v=682'; document.head.appendChild(l);
  var m = document.querySelector('meta[name=viewport]');
  if (m) m.setAttribute('content', 'width=device-width, initial-scale=1, viewport-fit=cover');

  var file = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  var TITLES = { 'kitchens.html': 'Order Food', 'index.html': 'Butchery', 'kitchen-partners.html': 'Cook with Azizo', 'fresh-market.html': 'Fresh Meat', 'meal-planner.html': 'Meal Planner', 'ready-to-eat.html': 'Ready to Eat', 'groceries.html': 'Groceries', 'recipes.html': 'Recipes', 'recipe.html': 'Recipe', 'butcheries.html': 'Partner Butcheries', 'rewards.html': 'Rewards', 'sell-with-azizo.html': 'Sell with Azizo', 'partner-portal.html': 'Partner sign-in', 'kitchen-portal.html': 'Cook sign-in', 'franchise.html': 'Franchise', 'franchisee.html': 'Franchisee', 'rider.html': 'Riders', 'kitchens-rider.html': 'Rider', 'staff.html': 'Staff', 'operations.html': 'Operations', 'admin.html': 'Admin', 'kitchens-admin.html': 'Kitchens admin', 'marketplace-admin.html': 'Marketplace admin', 'security-center.html': 'Security', 'outdoor-events.html': 'Outdoor Events', 'event-budget.html': 'Event Budget', 'budget.html': 'Meat Budget', 'reviews.html': 'Reviews', 'about.html': 'About Azizo', 'contact.html': 'Branches', 'faq.html': 'Help & FAQ', 'privacy.html': 'Privacy & refunds', 'areas.html': 'Areas we serve', 'statement.html': 'Statement', 'inspection-form.html': 'Inspection' };
  var ROOTS = { 'kitchens.html': 1, 'index.html': 1, 'kitchen-partners.html': 1 };
  if (/^kitchens-(syokimau|umoja|buruburu|utawala)\.html$/.test(file)) TITLES[file] = 'Order Food';
  var title = TITLES[file] || (document.title || 'Azizo').split(/[|—–-]/)[0].trim().slice(0, 28);

  var I = {
    menu: '<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
    cart: '<svg viewBox="0 0 24 24"><path d="M3 4h2l2.2 10.2a1.5 1.5 0 0 0 1.5 1.2h7.7a1.5 1.5 0 0 0 1.5-1.1L20 8H6.2"/><circle cx="9.5" cy="19.5" r="1.2"/><circle cx="16.5" cy="19.5" r="1.2"/></svg>',
    wa: '<svg viewBox="0 0 24 24"><path d="M4 20l1.2-4.2A8 8 0 1 1 8.3 18.9L4 20z"/><path d="M9.2 9.2c.3 2.3 2.4 4.4 4.7 4.7l1.2-1.1-1.9-1-.8.7a3.6 3.6 0 0 1-1.7-1.7l.7-.8-1-1.9-1.2 1.1z"/></svg>',
    food: '<svg viewBox="0 0 24 24"><path d="M4 12h16a8 8 0 0 1-16 0z"/><path d="M8 8c0-1.5 1.5-1.5 1.5-3M12 8c0-1.5 1.5-1.5 1.5-3M16 8c0-1.5 1.5-1.5 1.5-3"/></svg>',
    meat: '<svg viewBox="0 0 24 24"><path d="M5 14c0-5 4-9 9-9a5 5 0 0 1 5 5c0 5-4 9-9 9a5 5 0 0 1-5-5z"/><circle cx="14" cy="10" r="1.6"/></svg>',
    cook: '<svg viewBox="0 0 24 24"><path d="M7 11a4 4 0 1 1 3-6.6A4 4 0 0 1 17 8a3.5 3.5 0 0 1 0 3H7z"/><path d="M7 11v8h10v-8M10 14v2M14 14v2"/></svg>',
    more: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>'
  };
  var GROUPS = [
    { h: 'Eat', items: [
      ['🍲', 'Order food', 'Home kitchens near you', 'kitchens.html'],
      ['🍗', 'Ready to eat', 'Nyama choma, shawarma, fried chicken', 'ready-to-eat.html'],
      ['🎁', 'Curated meals', 'One-tap boxes, everything included', 'index.html#homeBoxes'],
      ['📅', 'Meal planner', 'Weeks of meat, 10% off', 'meal-planner.html'],
      ['📖', 'Recipes', 'Cook it yourself', 'recipes.html']] },
    { h: 'Shop', items: [
      ['🥩', 'Fresh meat', 'Beef, pork, chicken, fish', 'fresh-market.html'],
      ['🧂', 'Groceries', 'Meat-prep essentials', 'groceries.html'],
      ['🏪', 'Partner butcheries', 'Near you', 'butcheries.html'],
      ['🎉', 'Outdoor events', 'Bulk and catering', 'outdoor-events.html'],
      ['🧮', 'Event budget', 'Cost and quantities', 'event-budget.html']] },
    { h: 'Earn with Azizo', items: [
      ['👩‍🍳', 'Cook with Azizo', 'Earn from your home kitchen', 'kitchen-partners.html'],
      ['🛍️', 'Sell with Azizo', 'Become a partner butchery', 'sell-with-azizo.html'],
      ['🛵', 'Ride with Azizo', 'Deliver orders', 'kitchens-rider.html'],
      ['💼', 'Franchise', 'Own an Azizo butchery', 'franchise.html']] },
    { h: 'My account', items: [
      ['🍳', 'Cook sign-in', 'Kitchen partners', 'kitchen-portal.html'],
      ['🤝', 'Partner sign-in', 'Partner butcheries', 'partner-portal.html'],
      ['🏆', 'Rewards', 'Points and offers', 'rewards.html']] },
    { h: 'Team and owner', items: [
      ['👤', 'Staff', 'Staff sign-in', 'staff.html'],
      ['📋', 'Operations', 'Checklists, playbook, branches', 'operations.html'],
      ['🔑', 'Owner admin', 'Menu, prices, site', 'admin.html'],
      ['🍽️', 'Kitchens admin', 'Approve cooks, orders', 'kitchens-admin.html'],
      ['🛒', 'Marketplace admin', 'Partner butcheries', 'marketplace-admin.html']] },
    { h: 'About', items: [
      ['⭐', 'Reviews', 'What Nairobi says', 'reviews.html'],
      ['📍', 'Branches', 'Find us', 'contact.html'],
      ['🗺️', 'Areas we serve', 'Delivery zones', 'areas.html'],
      ['📖', 'Our story', 'About Azizo', 'about.html'],
      ['❓', 'Help and FAQ', 'Hours, delivery, payment', 'faq.html'],
      ['🔒', 'Privacy and refunds', '', 'privacy.html']] }
  ];
  var TABS = [
    ['kitchens.html', 'Order Food', I.food], ['index.html', 'Butchery', I.meat], ['kitchen-partners.html', 'Cook', I.cook], ['#more', 'Options', I.more]
  ];
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function build() {
    if (document.getElementById('azBar')) return;
    var root = !!ROOTS[file];
    var hasCart = typeof window.openCart === 'function';
    var bar = document.createElement('header'); bar.id = 'azBar';
    bar.innerHTML = '<button class="az-ib" id="azLead" aria-label="' + (root ? 'Options' : 'Back') + '">' + (root ? I.menu : I.back) + '</button>' +
      '<div class="az-title">' + esc(title) + '</div>' +
      (hasCart ? '<button class="az-ib" id="azCart" aria-label="Cart">' + I.cart + '<b id="azCartN" hidden>0</b></button>' : '') +
      '<a class="az-ib" href="https://wa.me/254724888057" aria-label="Order on WhatsApp">' + I.wa + '</a>';
    document.body.insertBefore(bar, document.body.firstChild);
    var tabs = document.createElement('nav'); tabs.id = 'azTabs';
    tabs.innerHTML = TABS.map(function (t) {
      var cur = t[0] === file || (t[0] === 'kitchens.html' && /^kitchens-(syokimau|umoja|buruburu|utawala)\.html$/.test(file));
      return t[0] === '#more' ? '<button data-more class="az-tab">' + t[2] + '<span>' + t[1] + '</span></button>' : '<a class="az-tab' + (cur ? ' on' : '') + '" href="' + t[0] + '">' + t[2] + '<span>' + t[1] + '</span></a>';
    }).join('');
    document.body.appendChild(tabs);
    var dr = document.createElement('div'); dr.id = 'azDrawer'; dr.setAttribute('aria-hidden', 'true');
    dr.innerHTML = '<div class="az-scrim" data-x></div><aside class="az-panel" role="dialog" aria-label="Options"><div class="az-phead"><img src="mascot-head.webp" alt="" width="44" height="44"><div><b>Azizo</b><small>Butchery, Grill &amp; Kitchens</small></div><button class="az-ib" data-x aria-label="Close">' + I.close + '</button></div><div class="az-pbody">' +
      GROUPS.map(function (g) {
        return '<h3>' + esc(g.h) + '</h3>' + g.items.map(function (i) {
          return '<a class="az-row" href="' + i[3] + '"><i>' + i[0] + '</i><span><b>' + esc(i[1]) + '</b>' + (i[2] ? '<small>' + esc(i[2]) + '</small>' : '') + '</span><em>›</em></a>';
        }).join('');
      }).join('') + '<p class="az-ver">Azizo app v6.8.2 · WhatsApp 0724 888 057</p></div></aside>';
    document.body.appendChild(dr);
    function open(v) { dr.classList.toggle('open', v); dr.setAttribute('aria-hidden', v ? 'false' : 'true'); de.classList.toggle('az-lock', v); }
    document.getElementById('azLead').onclick = function () { if (root) open(true); else if (history.length > 1) history.back(); else location.href = 'kitchens.html'; };
    tabs.querySelector('[data-more]').onclick = function () { open(true); };
    dr.addEventListener('click', function (e) { if (e.target.closest('[data-x]') || e.target.closest('a.az-row')) open(false); });
    var cb = document.getElementById('azCart'); if (cb) cb.onclick = function () { try { window.openCart(); } catch (e) {} };
    // keep the cart badge in step with the page's own counter
    var src = document.getElementById('cartCount'), dst = document.getElementById('azCartN');
    if (src && dst) { var sync = function () { var n = parseInt(src.textContent, 10) || 0; dst.textContent = n; dst.hidden = !n; }; sync(); new MutationObserver(sync).observe(src, { childList: true, characterData: true, subtree: true }); }
    // Order Food landing: Cook with Azizo comes first
    if (file === 'kitchens.html') {
      var hero = document.querySelector('.hero');
      if (hero && !document.getElementById('azCook')) {
        var c = document.createElement('a'); c.id = 'azCook'; c.href = 'kitchen-partners.html';
        c.innerHTML = '<span class="az-cook-i">👩‍🍳</span><span><b>Cook with Azizo</b><small>Turn your home kitchen into income. Apply in 2 minutes.</small></span><em>Apply ›</em>';
        hero.parentNode.insertBefore(c, hero);
      }
    }
    // Butchery tab: products first, "Our story" stays in Options
    if (file === 'index.html') { var t = document.getElementById('marketSearchMount'); if (t) t.setAttribute('data-az-first', '1'); }
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') open(false); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
